-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  jeu. 04 avr. 2019 à 20:21
-- Version du serveur :  10.1.37-MariaDB
-- Version de PHP :  7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `mathemagame`
--

-- --------------------------------------------------------

--
-- Structure de la table `enigme`
--

CREATE TABLE `enigme` (
  `ENIGME1` int(1) NOT NULL,
  `ENIGME2` int(2) NOT NULL,
  `ENIGME3` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `enigme`
--

INSERT INTO `enigme` (`ENIGME1`, `ENIGME2`, `ENIGME3`) VALUES
(9, 22, 2);

-- --------------------------------------------------------

--
-- Structure de la table `equipe`
--

CREATE TABLE `equipe` (
  `NOM` varchar(20) NOT NULL,
  `JOUEUR1` varchar(20) DEFAULT NULL,
  `JOUEUR2` varchar(20) DEFAULT NULL,
  `JOUEUR3` varchar(20) DEFAULT NULL,
  `JOUEUR4` varchar(20) DEFAULT NULL,
  `MEILLEURTPS` time DEFAULT '00:00:00',
  `PIRETPS` time DEFAULT '00:00:00',
  `ENJEU` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `indices`
--

CREATE TABLE `indices` (
  `INDICE1` varchar(200) NOT NULL,
  `INDICE2` varchar(200) NOT NULL,
  `INDICE3` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `indices`
--

INSERT INTO `indices` (`INDICE1`, `INDICE2`, `INDICE3`) VALUES
('Prenez bien le temps de faire le calcul étape par étape !', 'Relisez attentivement..', 'Un escargot mort reste toujours un escargot !!!');

-- --------------------------------------------------------

--
-- Structure de la table `joueur`
--

CREATE TABLE `joueur` (
  `ID` varchar(20) NOT NULL,
  `EMAIL` varchar(30) NOT NULL,
  `MDP` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `joueur`
--

INSERT INTO `joueur` (`ID`, `EMAIL`, `MDP`) VALUES
('Niki_Nar6', 'nicolas2.narcisse@gmail.com', 'mdp');

-- --------------------------------------------------------

--
-- Structure de la table `maitredujeu`
--

CREATE TABLE `maitredujeu` (
  `NOM` varchar(20) NOT NULL,
  `MESSAGEJOUEUR` varchar(400) NOT NULL,
  `MESSAGEMJ` varchar(400) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `equipe`
--
ALTER TABLE `equipe`
  ADD PRIMARY KEY (`NOM`);

--
-- Index pour la table `joueur`
--
ALTER TABLE `joueur`
  ADD PRIMARY KEY (`ID`);

--
-- Index pour la table `maitredujeu`
--
ALTER TABLE `maitredujeu`
  ADD PRIMARY KEY (`NOM`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
