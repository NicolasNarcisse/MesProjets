<html>
<body>
    <?php
    //connexion à la bdd
    try {
    $bdd=new PDO(
        "mysql:host=localhost;dbname=mathemagame;charset=utf8",
        "Nicolas",
        "0000",
        array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION)
    );
    }
    catch(Exception $e){
        die('Erreur fatale :'.$e -> getMessage());
    }
    ?>
</body>
</html>