<?php session_start();
        require("connect.php");
        if(isset($_POST['button'])) //bouton connexion normale 
        {
          $requete = 'SELECT email, mdp FROM joueur WHERE email = ? AND mdp = ?'; //on récupère l'email et le mdp du joueur dans la bdd
          $recup= $bdd-> prepare($requete);
          $recup -> execute(array($_POST['email'],$_POST['mdp']));
          $res = $recup->fetch();
          if($res)
          {
            if($_POST['email'] == $res['email'] && $_POST['mdp'] == $res['mdp']) // si c'est les mêmes info que ce qui a été rentré sur le site alors on peut aller choisir son équipe
            {
              header('Location: includes/equipes.php');
            }
            else
            {
              echo 'Votre pseudo ou mot de passe est incorrect';
            }
          }
        }
        elseif(isset($_POST['buttonMJ'])) // bouton maitre du jeu
        {
          //Même chose qu'avec le joueur mais pour le MJ
          $requete2 = 'SELECT email, mdp FROM joueur WHERE email = ? AND mdp = ?';
          $recup2= $bdd-> prepare($requete2);
          $recup2 -> execute(array($_POST['emailMJ'],$_POST['mdpMJ']));
          $res2 = $recup2->fetch();
          if($res2)
          {
            if($_POST['emailMJ'] == $res2['email'] && $_POST['mdpMJ'] == $res2['mdp'])
            {
              header('Location: includes/maitredujeu.php');
            }
            else
            {
              echo 'Votre pseudo ou mot de passe est incorrect';
            }
          }
        }
        else
        {
          //rien
        }
        ?>
<html>
    <head>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <link rel="stylesheet" href="css/connexion.css" />
        <title>My Escape Game</title>
    </head>
    <body>
        <header>
        <!-- Barre de Menu -->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
                <a class="navbar-brand" href="#">MathémaGame</a>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ml-auto"> <!--ml-auto permet de mettre à droite-->
                        <li class="nav-item active">
                            <a class="nav-link" href="pageaccueil.php">Accueil</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="inscription.php">Inscription</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="connexion.php">Connexion</a>
                        </li>
                    </ul>
                </div>
            </nav>    
        </header>
        
        <br><br>
        <div class="container-fluid">
          <div class="row">
            <span class="col-lg-4"></span>
            <h2 class="col-lg-4">Déja inscrit ?</h2>
            <span class="col-lg-4"></span>
          </div>
          <br><br>
          <div class="row">
            <span class="col-lg-2"></span>
            <h2 class="col-lg-2">Maitre du Jeu</h2>
            <span class="col-lg-4"></span>
            <h2 class="col-lg-2">Joueur</h2>
            <span class="col-lg-2"></span>
          </div>

          <br><br>
          <div class="row">
            <span class="col-lg-1"></span>
            <!-- Formulaire pour le MJ -->
            <div class="bordure col-lg-4">
              <form method="POST" action=""> 
              <br>
                <div class="row">
                  <span class="col-lg-3"></span>
                  <input class="col-lg-6" type="text" name="emailMJ" placeholder="Entrez votre email">
                  <span class="col-lg-1"></span>
                </div>
                <br>
                <div class="row"> 
                  <span class="col-lg-3"></span>
                  <input class="col-lg-6" type="password" name="mdpMJ" placeholder="Mot de passe">
                  <span class="col-lg-1"></span>
                </div>
                <br>
                <div class="row">
                  <span class="col-lg-5"></span>
                  <input class="col-lg-2" type="submit" name="buttonMJ">
                  <span class="col-lg-5"></span>
                </div>
              </form>
            </div>

            <span class="col-lg-2"></span>
            <!-- Formulaire pour les joueurs -->
            <div class="bordure col-lg-4">
              <form method="POST" action="">
              <br>
                <div class="row">
                  <span class="col-lg-3"></span>
                  <input class="col-lg-6" type="text" name="email" placeholder="Entrez votre email">
                  <span class="col-lg-1"></span>
                </div>
                <br>
                <div class="row"> 
                  <span class="col-lg-3"></span>
                  <input class="col-lg-6" type="password" name="mdp" placeholder="Mot de passe">
                  <span class="col-lg-1"></span>
                </div>
                <br>
                <div class="row">
                  <span class="col-lg-5"></span>
                  <input class="col-lg-2" type="submit" name="button">
                  <span class="col-lg-5"></span>
                </div>
              </form>
            </div>

            <span class="col-lg-1"></span>
          </div>
        </div>

        <?php
          if(isset($_POST['button']))
          {
            //on enregistre l'id de connexion dans une variable SESSION pour pouvoir l'afficher dans la barre de menu des pages suivantes
            $requete3 = 'SELECT id FROM joueur WHERE email = ?';  /* ici on prend l'email comme vérification car dans connexion on a pas renseigner  */
            $recup3= $bdd-> prepare($requete3);                   /* l'id donc on peut pas aller chercher l'id du formulaire (on peut aussi prendre le mdp) */
            $recup3 -> execute(array($_POST['email']));
            $res3 = $recup3->fetch();
            echo "".$res3['id']; 
            $_SESSION['id']=$res3['id'];
          }
          if(isset($_POST['buttonMJ']))
          {
            //Idem mais pour le MJ
            $requete3 = 'SELECT id FROM joueur WHERE email = ?';  
            $recup3= $bdd-> prepare($requete3);                   
            $recup3 -> execute(array($_POST['email']));
            $res3 = $recup3->fetch();
            echo "".$res3['id']; 
            $_SESSION['id']=$res3['id'];
          }
        ?>


        <footer class="footer">
            <hr size=5px>
            <p>Ce site à été réalisé par Nicolas NARCISSE et Luc OLIVO</p>
        </footer>

        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

    </body>


</html>