<?php session_start();
require("../connect.php");
//L'équipe n'est plus en jeu
$requete12="UPDATE equipe SET ENJEU=NULL WHERE NOM=?";
$recup12=$bdd -> prepare($requete12);
$recup12 -> execute(array($_SESSION['nomequipe']));
?>
<html>
    <head>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <link rel="stylesheet" href="../css/enigme1fin.css" />
        <title>My Escape Game</title>
    </head>
    <body>
        <header>
            <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
                <a class="navbar-brand" href="#">MathémaGame</a>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ml-auto"> <!--ml-auto permet de mettre à droite-->
                        <li class="nav-item">
                            <a class="nav-link" href="abandonner.php">Abandonner</a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link" href="#">
                            <?php 
                                require("../connect.php");
                                echo $_SESSION['id'];
                            ?> 
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>    
        </header>
        <?php
            require("../connect.php");
            $tempsmtn = microtime(true);
            $temps=$tempsmtn-$_SESSION['tempsenigme3'];
            $_SESSION['tempsenigme3']=gmdate("H:i:s",$temps);

            $_SESSION['enigme3fin']="fini";

            //on détruit le potentiel message qu'il y aurait été marqué précedement dans la table
            $requete9="UPDATE maitredujeu SET MESSAGEMJ=NULL WHERE NOM=?";
            $recup9=$bdd -> prepare($requete9);
            $recup9 -> execute(array($_SESSION['nomequipe']));
            
            //Gestion des stats de fin de jeu(meilleur/pire/tempsmoyen) 
            $tempsmtn2 = microtime(true);
            $temps2=$tempsmtn2-$_SESSION['tempsdebut'];
            $tempsfin=gmdate("H:i:s",$temps2);

            //MEILLEUR
            $requete= "SELECT MEILLEURTPS FROM equipe WHERE NOM = ?";
            $recup= $bdd-> prepare($requete);
            $recup -> execute(array($_SESSION['nomequipe']));
            $res= $recup ->fetch();
            if($res['MEILLEURTPS']==NULL) //gère le cas où c'est la première partie et où ya pas de temps
            {
                $requete2="UPDATE equipe SET MEILLEURTPS=? WHERE NOM=?";
                $recup2=$bdd -> prepare($requete2);
                $recup2 -> execute(array($tempsfin,$_SESSION['nomequipe']));
            }
            elseif($res['MEILLEURTPS']>$tempsfin) //nouveau meilleur tps
            {
                $requete3="UPDATE equipe SET MEILLEURTPS=? WHERE NOM=?";
                $recup3=$bdd -> prepare($requete3);
                $recup3 -> execute(array($tempsfin,$_SESSION['nomequipe']));
            }

            //PIRE
            $requete4= "SELECT PIRETPS FROM equipe WHERE NOM = ?";
            $recup4= $bdd-> prepare($requete4);
            $recup4 -> execute(array($_SESSION['nomequipe']));
            $res4= $recup4 ->fetch();
            if($res4['PIRETPS']==NULL) //gère le cas où c'est la première partie et où ya pas de temps
            {
                $requete5="UPDATE equipe SET PIRETPS=? WHERE NOM=?";
                $recup5=$bdd -> prepare($requete5);
                $recup5 -> execute(array($tempsfin,$_SESSION['nomequipe']));
            }
            elseif($res4['PIRETPS']<$tempsfin) //nouveau pire tps
            {
                $requete6="UPDATE equipe SET PIRETPS=? WHERE NOM=?";
                $recup6=$bdd -> prepare($requete6);
                $recup6 -> execute(array($tempsfin,$_SESSION['nomequipe']));
            }
        ?>

        <div class="container-fluid">
            <form method="POST" action="pagejeu.php">
            <div class="row">
                <span class="col-lg-4"></span>
                <div class="col-lg-4">
                    <div class="bordure">
                        <h2>Enigme n°3</h2>
                        <p>Bravo, vous avez résolu l'enigme 3 !!! En seulement <?php echo "".$_SESSION['tempsenigme3']?> !!!</p>
                        <br>
                        <input class="button" type="submit" name="button">
                    </div>
                </div>
                <span class="col-lg-4"></span>
            </div>
            </form> 
        </div>



        <footer class="footer">
            <hr size=5px>
            <p>Ce site à été réalisé par Nicolas NARCISSE et Luc OLIVO</p>
        </footer>

        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

    </body>


</html>