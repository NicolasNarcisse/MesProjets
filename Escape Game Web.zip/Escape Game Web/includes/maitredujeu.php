<?php session_start() ?>
<html>
    <head>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <link rel="stylesheet" href="../css/maitredujeu.css" />
        <title>My Escape Game</title>
    </head>
    <body>
        <header>
            <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
                <a class="navbar-brand" href="#">MathémaGame</a>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ml-auto"> <!--ml-auto permet de mettre à droite-->
                        <li class="nav-item">
                            <a class="nav-link" href="abandonner.php">Abandonner</a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link" href="#">
                            <?php 
                                require("../connect.php");
                                echo $_SESSION['id'];
                            ?> 
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>    
        </header>


                   

        <div class="container-fluid">
            <form method="POST" action="#">
            <div class="row">
                <span class="col-lg-2"></span>

                <div class="col-lg-4">
                    <div class="bordure">
                    <h2>Equipe en Jeu</h2>
            <p>
                <?php
                $tempsmtn = microtime(true);
                $temps=$tempsmtn-$_SESSION['tempsdebut'];
                $tempsconv=gmdate("H:i:s",$temps);
                echo "La partie a commencé depuis : ".$tempsconv;
                echo '<br>';

                require("../connect.php");
                /*************************************  AFFICHAGE DE CARACTERISTIQUE DE L'EQUIPE ****************************************/
                echo "L'équipe :";
                echo '<br>';

                $requete3= "SELECT NOM FROM equipe WHERE NOM = ?";
                $recup3= $bdd-> prepare($requete3);
                $recup3 -> execute(array($_SESSION['nomequipe']));
                $res3= $recup3 ->fetch();
                echo "     - Nom : ".$res3['NOM'];
                echo '<br>';

                $requete4= "SELECT JOUEUR1 FROM equipe WHERE NOM = ?";
                $recup4= $bdd-> prepare($requete4);
                $recup4 -> execute(array($_SESSION['nomequipe']));
                $res4= $recup4 ->fetch();
                echo "     - Joueur 1 : ".$res4['JOUEUR1'];
                echo '<br>';

                $requete5= "SELECT JOUEUR2 FROM equipe WHERE NOM = ?";
                $recup5= $bdd-> prepare($requete5);
                $recup5 -> execute(array($_SESSION['nomequipe']));
                $res5= $recup5 ->fetch();
                if($res5['JOUEUR2']==NULL)
                {
                    /* on affiche pas le joueur */
                }
                else
                {
                    echo "     - Joueur 2 : ".$res5['JOUEUR2'];
                    echo '<br>';
                }
                

                $requete6= "SELECT JOUEUR3 FROM equipe WHERE NOM = ?";
                $recup6= $bdd-> prepare($requete6);
                $recup6 -> execute(array($_SESSION['nomequipe']));
                $res6= $recup6 ->fetch();
                if($res6['JOUEUR3']==NULL)
                {
                    /* on affiche pas le joueur */
                }
                else
                {
                    echo "     - Joueur 3 : ".$res6['JOUEUR3'];
                    echo '<br>';
                }
                

                $requete7= "SELECT JOUEUR4 FROM equipe WHERE NOM = ?";
                $recup7= $bdd-> prepare($requete7);
                $recup7 -> execute(array($_SESSION['nomequipe']));
                $res7= $recup7 ->fetch();
                if($res7['JOUEUR4']==NULL)
                {
                    /* on affiche pas le joueur */
                }
                else
                {
                    echo "     - Joueur 4 : ".$res7['JOUEUR4'];
                    echo '<br>';
                }
                /***********************************  ********************************************************/
                echo '<br>';
                //statistiques temporelles
                if($_SESSION['enigme1fin'] == "fini")
                {
                    echo 'Ils ont fini l\'enigme 1 en '.$_SESSION['tempsenigme1'];
                }
                else
                {
                    echo 'Ils n\'ont pas encore résolu l\'enigme 1 !';
                }
                echo '<br>';
                if($_SESSION['enigme2fin'] == "fini")
                {
                    echo 'Ils ont fini l\'enigme 2 en '.$_SESSION['tempsenigme2'];
                }
                else
                {
                    echo 'Ils n\'ont pas encore résolu l\'enigme 2 !';
                }
                echo '<br>';
                if($_SESSION['enigme3fin'] == "fini")
                {
                    echo 'Ils ont fini l\'enigme 3 en '.$_SESSION['tempsenigme3'];
                }
                else
                {
                    echo 'Ils n\'ont pas encore résolu l\'enigme 3 !';
                }
                echo '<br>';
                //affichage du meilleur temps de résolution de l'équipe
                $requete11="SELECT MEILLEURTPS FROM equipe WHERE NOM=?";
                $recup11= $bdd -> prepare($requete11);
                $res11 = $recup11 -> execute(array($_SESSION['nomequipe']));
                $res11= $recup11 ->fetch();
                echo "Actuel meilleur temps : ".$res11['MEILLEURTPS'];
                echo '<br>';
                //affichage du pire temps de résolution de l'équipe
                $requete12="SELECT PIRETPS FROM equipe WHERE NOM=?";
                $recup12= $bdd -> prepare($requete12);
                $res12 = $recup12 -> execute(array($_SESSION['nomequipe']));
                $res12= $recup12 ->fetch();
                echo "Actuel pire temps : ".$res12['PIRETPS'];

                echo '<br><br>';
                //affichage du message de l'équipe
                $requete9= "SELECT MESSAGEJOUEUR FROM maitredujeu";
                $recup9= $bdd-> prepare($requete9);
                $res9 = $recup9 -> execute();
                $res9= $recup9 ->fetch();
                echo "Question du joueur : ".$res9['MESSAGEJOUEUR'];
            
            
            ?> 
            
            </p>
                    </div>
                </div>


                <span class="col-lg-1"></span>
                <div class="col-lg-3">
                    <div class="bordureIndice">
                        <br>
                        <h4>Envoyer un indice :</h4>
                        <br>
                        <input class="col-lg-10" type="text" id="indice" name="indice" placeholder="Rentrez votre indice">
                        <br><br>
                        <input class="button col-lg-5" id="buttonIndice" type="submit" name="buttonIndice">
                    </div>
                </div>
                <span class="col-lg-3"></span>
            </div>
            </form> 
        </div>

        <?php
            require("../connect.php");
            if(isset($_POST['buttonIndice']))
            {
                //on détruit le potentiel message qu'il y aurait été marqué précedement dans la table
                $requete10="UPDATE maitredujeu SET MESSAGEMJ=NULL WHERE NOM=?";
                $recup10=$bdd -> prepare($requete10);
                $recup10 -> execute(array($_SESSION['nomequipe']));
                //requete qui insert le message dans la table Message -> sous table Joueur (l'autre c'est la sous table MJ)
                $requete8="UPDATE maitredujeu SET MESSAGEMJ=? WHERE NOM=?";
                $recup8=$bdd -> prepare($requete8);
                $recup8 -> execute(array($_POST['indice'],$_SESSION['nomequipe']));
            }
        ?>

        <footer class="footer">
            <hr size=5px>
            <p>Ce site à été réalisé par Nicolas NARCISSE et Luc OLIVO</p>
        </footer>

        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

    </body>


</html>