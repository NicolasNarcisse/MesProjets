<?php session_start()
?>
<html>
    <head>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <link rel="stylesheet" href="../css/jeu1.css" />
        <title>My Escape Game</title>
    </head>
    <body>
        <header>
            <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
                <a class="navbar-brand" href="#">MathémaGame</a>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ml-auto"> <!--ml-auto permet de mettre à droite-->
                        <li class="nav-item">
                            <a class="nav-link" href="abandonner.php">Abandonner</a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link" href="#">
                            <?php 
                                require("../connect.php");
                                echo $_SESSION['id'];
                            ?> 
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>    
        </header>
        
        <div id="stat">
            <div class="fenetreStat"> <!-- fenetre de stats -->
                <a class="fermer" href="#"><img alt="Fermer" title="Fermer la fenêtre" class="btn-fermer" src="../images/fermer.png" /></a>
                <h2>Statistiques de Jeu</h2>
                <?php
                if(isset($_POST['stat']))
                {
                    header('Location: enigme2.php#stat');                    
                }
                $tempsmtn = microtime(true);
                $temps=$tempsmtn-$_SESSION['tempsdebut'];
                $tempsconv=gmdate("H:i:s",$temps);
                echo "Votre partie a commencé depuis : ".$tempsconv;
                echo '<br>';

                require("../connect.php");
/*************************************  AFFICHAGE DE CARACTERISTIQUE DE L'EQUIPE ****************************************/
                echo "Votre équipe :";
                echo '<br>';

                $requete3= "SELECT NOM FROM equipe WHERE NOM = ?";
                $recup3= $bdd-> prepare($requete3);
                $recup3 -> execute(array($_SESSION['nomequipe']));
                $res3= $recup3 ->fetch();
                echo "     - Nom : ".$res3['NOM'];
                echo '<br>';

                $requete4= "SELECT JOUEUR1 FROM equipe WHERE NOM = ?";
                $recup4= $bdd-> prepare($requete4);
                $recup4 -> execute(array($_SESSION['nomequipe']));
                $res4= $recup4 ->fetch();
                echo "     - Joueur 1 : ".$res4['JOUEUR1'];
                echo '<br>';

                $requete5= "SELECT JOUEUR2 FROM equipe WHERE NOM = ?";
                $recup5= $bdd-> prepare($requete5);
                $recup5 -> execute(array($_SESSION['nomequipe']));
                $res5= $recup5 ->fetch();
                if($res5['JOUEUR2']==NULL)
                {
                    /* on affiche pas le joueur */
                }
                else
                {
                    echo "     - Joueur 2 : ".$res5['JOUEUR2'];
                    echo '<br>';
                }
                

                $requete6= "SELECT JOUEUR3 FROM equipe WHERE NOM = ?";
                $recup6= $bdd-> prepare($requete6);
                $recup6 -> execute(array($_SESSION['nomequipe']));
                $res6= $recup6 ->fetch();
                if($res6['JOUEUR3']==NULL)
                {
                    /* on affiche pas le joueur */
                }
                else
                {
                    echo "     - Joueur 3 : ".$res6['JOUEUR3'];
                    echo '<br>';
                }
                

                $requete7= "SELECT JOUEUR4 FROM equipe WHERE NOM = ?";
                $recup7= $bdd-> prepare($requete7);
                $recup7 -> execute(array($_SESSION['nomequipe']));
                $res7= $recup7 ->fetch();
                if($res7['JOUEUR4']==NULL)
                {
                    /* on affiche pas le joueur */
                }
                else
                {
                    echo "     - Joueur 4 : ".$res7['JOUEUR4'];
                    echo '<br>';
                }
/***********************************  ********************************************************/


                /* temps enigme 1 */
                echo "Vous avez résolu l".'\''."enigme 1 en : ".$_SESSION['tempsenigme1'];
                echo '<br>';
                /* temps enigme 2 */
                echo 'Vous n\'avez pas encore résolu l\'enigme 2 !';
                echo '<br>';
                /* temps enigme 3 */
                echo 'Vous n\'avez pas encore résolu l\'enigme 3 !';
                echo '<br>';
                ?>
            </div>
        </div>

        <div id="indice">
            <div class="fenetreIndice"> <!-- fenetre de l'indice -->
                <a class="fermer" href="#"><img alt="Fermer" title="Fermer la fenêtre" class="btn-fermer" src="../images/fermer.png" /></a>
                <h2>Indice</h2>
                <?php
                    if(isset($_POST['indice']))
                    {
                        header('Location: enigme2.php#indice');
                    }
                    require("../connect.php");
                    $requete= $bdd ->query('SELECT INDICE2 FROM indices');
                    $res=$requete->fetch();
                    echo "".$res['INDICE2'];
                ?>
            </div>
        </div>
        
<!-------- Enigme 2 ---------->
        <div class="container-fluid">
            <form method="POST" action="#">
            <div class="row">
                <span class="col-lg-1"></span>
                <div class="col-lg-2">
                    <div class="bordureIndice">
                        <button class="indice" type="submit" name="indice">Indice</button>
                    </div>
                    <div class="bordureStat">
                        <button class="stat" type="submit" name="stat">Statistiques</button>
                    </div>
                </div>

                <span class="col-lg-1"></span>
                <div class="col-lg-4">
                    <div class="bordure">
                        <h2>Enigme n°2</h2>
                        <p>En sortant du puit, vous rencontrez Elsa, la soeur de Philippe. Elsa a 4 ans et Philippe à la moitié de son âge. Dans 20 ans, Elsa aura donc 24 ans. Mais alors quel âge aura Phillipe ? 
                        </p>
                        <br>
                        <input class="col-lg-9" type="text" id="" name="enigme2" placeholder="Votre réponse (mettez juste un nombre)">
                        <input class="button" type="submit" name="button">
                        <br> <br>
                        <p>
                            <?php
                                $requete10= "SELECT MESSAGEMJ FROM maitredujeu";
                                $recup10= $bdd-> prepare($requete10);
                                $res10 = $recup10 -> execute();
                                $res10= $recup10 ->fetch();
                                echo "Réponse du Maitre du Jeu : ".$res10['MESSAGEMJ'];
                            ?>
                        </p>
                    </div>
                </div>

                <?php
                    require("../connect.php");
                    if(isset($_POST['button']) && !empty($_POST['enigme2']))
                    {
                        $requete2= $bdd ->query('SELECT ENIGME2 FROM enigme');
                        $res2=$requete2->fetch();
                        //on vérifie que la réponse fournit par l'équipe est correcte
                        if($_POST['enigme2']==$res2['ENIGME2'])
                        {
                            header('Location: enigme2fin.php');
                        }
                        else
                        {
                            header('Location: enigme2.php#faux');
                        }
                    }
                ?>

                <span class="col-lg-1"></span>
                <div class="col-lg-2">
                    <div class="bordureQuestion">
                        <br>
                        <h4>Une question ?</h4>
                        <br>
                        <input class="col-lg-10" type="text" id="question" name="question" placeholder="Votre demande">
                        <br><br><br>
                        <input class="button col-lg-5" id="buttonQuestion" type="submit" name="buttonQuestion">
                    </div>
                </div>
                <span class="col-lg-1"></span>
            </div>
            </form> 
        </div>

        <div id="faux">
            <div class="fenetreFaux">
                <a class="fermer" href="#"><img alt="Fermer" title="Fermer la fenêtre" class="btn-fermer" src="../images/fermer.png" /></a>
                <h2>OUPS !</h2>
                <p>Vous vous êtes trompé..</p>
            </div>
        </div>
        
        <?php
            require("../connect.php");
            if(isset($_POST['buttonQuestion']))
            {
                //on détruit le potentiel message qu'il y aurait été marqué précedement dans la table
                $requete9="UPDATE maitredujeu SET MESSAGEJOUEUR=NULL WHERE NOM=?";
                $recup9=$bdd -> prepare($requete9);
                $recup9 -> execute(array($_SESSION['nomequipe']));
                //on insert le message dans la table message
                $requete8="UPDATE maitredujeu SET MESSAGEJOUEUR=? WHERE NOM=?";
                $recup8=$bdd -> prepare($requete8);
                $recup8 -> execute(array($_POST['question'],$_SESSION['nomequipe']));
            }
        ?>

        <footer class="footer">
            <hr size=5px>
            <p>Ce site à été réalisé par Nicolas NARCISSE et Luc OLIVO</p>
        </footer>

        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

    </body>


</html>