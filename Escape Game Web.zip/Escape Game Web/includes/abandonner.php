<?php
// On démarre la session
session_start ();
//On détruit les messages de la bdd entre le MJ et l'équipe
require("../connect.php");
$requete="DELETE FROM maitredujeu WHERE NOM=?";
$recup=$bdd -> prepare($requete);
$recup -> execute(array($_SESSION['nomequipe']));
//On dit que l'équipe n'est plus en jeu
$requete12="UPDATE equipe SET ENJEU=NULL WHERE NOM=?";
$recup12=$bdd -> prepare($requete12);
$recup12 -> execute(array($_SESSION['nomequipe']));
// On détruit les variables de notre session
session_unset ();

// On détruit notre session
session_destroy ();

// On redirige le visiteur vers la page d'accueil
header ('location: ../connexion.php');
?>