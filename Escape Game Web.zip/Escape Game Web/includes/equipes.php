<?php session_start() ?>

<html>
    <head>
        <meta charset="utf-8" />
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <link rel="stylesheet" href="../css/equipes.css" />
        <title>My Escape Game</title>
    </head>
    <body>
        <header>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <a class="navbar-brand" href="#">MathémaGame</a>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto"> <!--ml-auto permet de mettre à droite-->
                    <li class="nav-item">
                        <a class="nav-link" href="abandonner.php">Abandonner</a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="#">
                        <?php 
                            require("../connect.php");
                            echo $_SESSION['id'];                      
                        ?>
                        </a>
                    </li>
                </ul>
            </div>
        </nav>    
        </header>

        <br><br>
        <!-- Formulaire pour l'équipe -->
        <div class="container-fluid">
            <div class="row">
                <span class="col-lg-4"></span>
                <h2 class="col-lg-4">Quelle est votre équipe ?</h2>
                <span class="col-lg-4"></span>
            </div>
            <br><br>
            <div class="bordure">
                <form method="POST" action="#">
                <br>
                <div class="row">
                    <span class="col-lg-3"></span>
                    <input class="col-lg-6" type="text" id="nomequipe" name="nomequipe" placeholder="Entrez votre nom d'équipe">
                    <span class="col-lg-3"></span>
                </div>
                <br>
                <div class="row"> 
                    <span class="col-lg-3"></span>
                    <input class="col-lg-6" type="text" id="nbequipe" name="nbequipe" placeholder="Entrez le nombre de joueur (max 4)">
                    <span class="col-lg-3"></span>
                </div>
                <br>
                <div class="row">
                    <span class="col-lg-5"></span>
                    <input class="col-lg-2" type="submit" name="button">
                    <span class="col-lg-5"></span>
                </div>
                </form>
            </div>
        </div>

        <?php 
            if(isset($_POST['button']) && isset($_POST['nomequipe']))
            {
                //on stocke les infos de nom d'équipe et de nombre de joueur en SESSIOB
                $_SESSION['nomequipe']=$_POST['nomequipe'];
                $_SESSION['nbequipe']=$_POST['nbequipe'];
                header('location: nomjoueurequipe.php');
            }
        ?>

        <footer class="footer">
            <hr size=5px>
            <p>Ce site à été réalisé par Nicolas NARCISSE et Luc OLIVO</p>
        </footer>

        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

    </body>
</html>