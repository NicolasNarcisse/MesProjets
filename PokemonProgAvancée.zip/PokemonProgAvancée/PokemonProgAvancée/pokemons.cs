﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokemonProgAvancée
{
    class Pokemons : BddPokemon // Les pokémons sont héritiés de la classe BDDPokemon
    {

        public string Nom { get; private set; }
        public int Pv { get; set; }
        public int Puissance { get; private set; }
        public string Type { get; private set; }
        public string Faiblesse { get; private set; }
        public int NbMort { get; set; } // Compteur pour savoir quand le pokémon  doit évoluer (quand NbMort=2)
        public int PvMax { get; private set; } // Sert à garder en mémoire le nb de pv pour pouvoir les remettre à jour après un combat
        public int stade { get; set; } // Permet de savoir à quel stade d'évolution il se trouve afin qu'il ne puisse pas évoluer plus de 2 fois

        public Pokemons(string nom, int pv, int puissance, string type, string faiblesse) // Constructeur par défaut d'un pokémon
        {
            Nom = nom;
            Pv = pv;
            Puissance = puissance;
            Type = type;
            Faiblesse = faiblesse;
            PvMax = pv;
            NbMort = 0;
            stade = 0;
        }

        public void Reset() // Sert à remettre à jour les pv à la fin d'un combat
        {
            Pv = PvMax;
        }

        public Pokemons Evolution(Pokemons pokemon)
        {
            //il prend 100 Pv en plus et 100 de puissance en plus quand il évolue
            if (stade <= 2) // il évolue uniquement si il n'a pas déjà évolué plus de 2 fois
            {
                stade++;
                pokemon.PvMax += 100;
                pokemon.Pv = PvMax;
                pokemon.Puissance += 100;
                return pokemon;
            }
            else
            {
                return pokemon;
            }
        }

    }
}
