﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokemonProgAvancée
{
    class Program
    {
        static void Main(string[] args)
        {
            string rejoue = "oui";
            do
            {
                Console.WindowHeight = 40;
                Console.WindowWidth = 120;

                //Affichage de la page de présentation
                Console.WriteLine("\n\n\n\n\n\n\n");

                Console.WriteLine("     ____  _                                            _                   _        __  __                 _      ");
                Console.WriteLine("    |  _ \\(_)                                          | |                 | |      |  \\/  |               | |     ");
                Console.WriteLine("    | |_) |_  ___ _ ____   _____ _ __  _   _  ___    __| | __ _ _ __  ___  | | ___  | \\  / | ___  _ __   __| | ___ ");
                Console.WriteLine("    |  _ <| |/ _ \\ '_ \\ \\ / / _ \\ '_ \\| | | |/ _ \\  / _` |/ _` | '_ \\/ __| | |/ _ \\ | |\\/| |/ _ \\| '_ \\ / _` |/ _ \\");
                Console.WriteLine("    | |_) | |  __/ | | \\ V /  __/ | | | |_| |  __/ | (_| | (_| | | | \\__ \\ | |  __/ | |  | | (_) | | | | (_| |  __/");
                Console.WriteLine("    |____/|_|\\___|_| |_|\\_/ \\___|_| |_|\\__,_|\\___|  \\__,_|\\__,_|_| |_|___/ |_|\\___| |_|  |_|\\___/|_| |_|\\__,_|\\___|");
                Console.WriteLine("\n\n\n");

                Console.WriteLine("\t\t\t      _                _____        _                                       ");
                Console.WriteLine("\t\t\t     | |              |  __ \\      | |                                      ");
                Console.WriteLine("\t\t\t   __| |  ___  ___    | |__) |___  | | __ ___  _ __ ___    ___   _ __   ___ ");
                Console.WriteLine("\t\t\t  / _` | / _ \\/ __|   |  ___// _ \\ | |/ // _ \\| '_ ` _ \\  / _ \\ | '_ \\ / __|");
                Console.WriteLine("\t\t\t | (_| ||  __/\\__ \\   | |   | (_) ||   <|  __/| | | | | || (_) || | | |\\__ \\");
                Console.WriteLine("\t\t\t  \\__,_| \\___||___/   |_|    \\___/ |_|\\_\\\\___||_| |_| |_| \\___/ |_| |_||___/");
                Console.WriteLine("\n\n\n\n");

                Console.WriteLine("\t\t\t\t\t\t\t\t\t\t    Lucas Chalan et Nicolas Narcisse");
                Console.WriteLine("\n\n\n\n\n\n");
                Console.WriteLine("\t\t\t\t\t\t     Appuyez sur ENTER");

                Console.ReadKey();
                Console.Clear();

                // Affichage de la page de règle et demande du nom du joueur

                Console.WriteLine("\t\t\t\t\t  _____            _");
                Console.WriteLine("\t\t\t\t\t |  __ \\          | |          ");
                Console.WriteLine("\t\t\t\t\t | |__) |___  __ _| | ___  ___ ");
                Console.WriteLine("\t\t\t\t\t |  _  // _ \\/ _` | |/ _ \\/ __|");
                Console.WriteLine("\t\t\t\t\t | | \\ \\  __/ (_| | |  __/\\__ \\");
                Console.WriteLine("\t\t\t\t\t |_|  \\_\\___|\\__, |_|\\___||___/");
                Console.WriteLine("\t\t\t\t\t              __/ |            ");
                Console.WriteLine("\t\t\t\t\t             |___/             \n");

                string nomDuJoueur;
                do // Demande du nom du joueur (limité à 7 caractères)
                {
                    Console.WriteLine("Quel est ton nom de dresseur ? (7 caractères maximum)");
                    nomDuJoueur = Console.ReadLine();
                } while (nomDuJoueur.Length > 7);


                Console.WriteLine("Salut " + nomDuJoueur + " ! Tu es venu pour le Tournoi International des Pokémons Légendaires Extraordinaires (TIPLE pour les intimes) ?");
                Console.WriteLine("Tu es au bon endroit !");
                Console.WriteLine("Nous allons t'expliquer tout d'abord quelques règles de base qui feront de toi un bon dresseur");
                Console.WriteLine("Enfin tu connais peut-être déjà les règles ? (o/n)");

                string reponse = Console.ReadLine(); //Demande si le joueur veut plus de règles

                if (reponse == "n")
                {
                    Console.WriteLine("\nAlors c'est simple, tu vas avoir 3 Pokémons qui te seront attribués aléatoirement. Oui oui aléatoirement.. Il y en a 48 donc si tout le monde pouvait choisir ça nous prendrais plusieurs jours ! Et le temps c'est de l'argent ;)");
                    Console.WriteLine("Chaque Pokémons a un certain nombre de points de vie (Pv), une puissance d'attaque, un type et une faiblesse.");
                    Console.WriteLine("La faiblesse est associé au type donc si ton pokémon est Feu par exemple il craindra tout les Pokémons Eau !");
                    Console.WriteLine("Là tu vas nous dire \"Ouai mais vas y je connais pas tout les types de Pokémons bla bla bla\".. \nTUT TUT TUT on se détend voilà tout les types possible :");
                    Console.WriteLine("Il y en 6 en tout : Feu, Air, Herbe, Elec, Terre et Eau !");
                    Console.WriteLine("Pour se qui est des faiblesses ne t'inquiètes pas elles te seront marqués pendant chaque combat !");
                    Console.WriteLine("Ensuite, c'est facile, vous êtes 16 au premier tour, 8 au second, 4 au troisième et viens enfin la grande finale !!!\nA la clé un Pokémon PapiMami sauvage a gagner !!!!!!!");
                    Console.WriteLine("Bon maintenant que tout est dit, BON JEU ET BONNE CHANCE :)");
                    Console.ReadKey();
                }

                // Création d'une liste d'équipes avec le nom du joueur en plus grâce au constructeur ListeEquipe

                ListeEquipe listeEquipe = new ListeEquipe(nomDuJoueur);

                // Création du tableau de huitième de finale

                List<Equipe> TableauSuivant = listeEquipe.listeEquipe;
                Tableaux huitieme = new Tableaux(TableauSuivant);

                //Affichage

                Console.WriteLine("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t");
                Console.WriteLine("\t\t\t\t\t  _    _       _ _   _  __                 ");
                Console.WriteLine("\t\t\t\t\t | |  | |     (_) | (_) \\_\\                ");
                Console.WriteLine("\t\t\t\t\t | |__| |_   _ _| |_ _  ___ _ __ ___   ___ ");
                Console.WriteLine("\t\t\t\t\t |  __  | | | | | __| |/ _ \\ '_ ` _ \\ / _ \\");
                Console.WriteLine("\t\t\t\t\t | |  | | |_| | | |_| |  __/ | | | | |  __/");
                Console.WriteLine("\t\t\t\t\t |_|  |_|\\__,_|_|\\__|_|\\___|_| |_| |_|\\___|");
                Console.WriteLine("\t\t\t\t\t                                           ");
                Console.WriteLine(huitieme);
                Console.ReadKey();

                TableauSuivant.Clear(); // On nettoie la liste contenant tous les joueurs qui seront présents au tour suivant (ayant gagné leur combat)

                for (int i = 0; i < 8; i++) // On fait jouer tous les matchs (automatiques si c'est des ordinateurs, controlé si c'est le joueur)
                {
                    Combat match = new Combat(huitieme.round[i, 1], huitieme.round[i, 0]); // Combat
                    Equipe equipe = match.JoueurGagnant; // On récupère le joueur gagnant du match et on l'ajoute à la liste des gagnants
                    TableauSuivant.Add(equipe);
                }

                //Création du tableau des quarts

                Tableaux quart = new Tableaux(TableauSuivant);

                // Affichage
                Console.WriteLine("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t");
                Console.WriteLine("\t\t\t\t\t   ____                       _   ");
                Console.WriteLine("\t\t\t\t\t  / __ \\                     | |  ");
                Console.WriteLine("\t\t\t\t\t | |  | | _   _   __ _  _ __ | |_ ");
                Console.WriteLine("\t\t\t\t\t | |  | || | | | / _` || '__|| __|");
                Console.WriteLine("\t\t\t\t\t | |__| || |_| || (_| || |   | |_ ");
                Console.WriteLine("\t\t\t\t\t  \\___\\_\\ \\__,_| \\__,_||_|    \\__|");
                Console.WriteLine("\t\t\t\t\t                              ");
                Console.WriteLine(quart);
                Console.ReadKey();

                TableauSuivant.Clear(); // On nettoie la liste contenant tous les joueurs qui seront présents au tour suivant (ayant gagné leur combat)

                for (int i = 0; i < 4; i++) // On fait jouer tous les matchs (automatiques si c'est des ordinateurs, controlé si c'est le joueur)
                {
                    Combat match = new Combat(quart.round[i, 1], quart.round[i, 0]); // Combat
                    Equipe equipe = match.JoueurGagnant; // On récupère le joueur gagnant du match et on l'ajoute à la liste des gagnants
                    TableauSuivant.Add(equipe);
                }

                //Création du tableau des demis

                Tableaux demi = new Tableaux(TableauSuivant);

                //demi
                Console.WriteLine("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t");
                Console.WriteLine("\t\t\t      _____                    _    ______  _                _       ");
                Console.WriteLine("\t\t\t     |  __ \\                  (_)  |  ____|(_)              | |      ");
                Console.WriteLine("\t\t\t     | |  | |  ___  _ __ ___   _   | |__    _  _ __    __ _ | |  ___ ");
                Console.WriteLine("\t\t\t     | |  | | / _ \\| '_ ` _ \\ | |  |  __|  | || '_ \\  / _` || | / _ \\");
                Console.WriteLine("\t\t\t     | |__| ||  __/| | | | | || |  | |     | || | | || (_| || ||  __/");
                Console.WriteLine("\t\t\t     |_____/  \\___||_| |_| |_||_|  |_|     |_||_| |_| \\__,_||_| \\___|");
                Console.WriteLine("\t\t\t                                                                     ");
                Console.WriteLine(demi);
                Console.ReadKey();

                TableauSuivant.Clear(); // On nettoie la liste contenant tous les joueurs qui seront présents au tour suivant (ayant gagné leur combat)

                for (int i = 0; i < 2; i++) // On fait jouer tous les matchs (automatiques si c'est des ordinateurs, controlé si c'est le joueur)
                {
                    Combat match = new Combat(demi.round[i, 1], demi.round[i, 0]); // Combat
                    Equipe equipe = match.JoueurGagnant; // On récupère le joueur gagnant du match et on l'ajoute à la liste des gagnants
                    TableauSuivant.Add(equipe);
                }

                //Création du tableau de la finale

                Tableaux finale = new Tableaux(TableauSuivant);

                //finale
                Console.WriteLine("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t");
                Console.WriteLine("\t\t\t\t\t  ______  _                _       ");
                Console.WriteLine("\t\t\t\t\t |  ____|(_)              | |      ");
                Console.WriteLine("\t\t\t\t\t | |__    _  _ __    __ _ | |  ___ ");
                Console.WriteLine("\t\t\t\t\t |  __|  | || '_ \\  / _` || | / _ \\");
                Console.WriteLine("\t\t\t\t\t | |     | || | | || (_| || ||  __/");
                Console.WriteLine("\t\t\t\t\t |_|     |_||_| |_| \\__,_||_| \\___|");
                Console.WriteLine("\t\t\t\t\t                                   ");
                Console.WriteLine(finale);
                Console.ReadKey();

                TableauSuivant.Clear(); // On nettoie la liste contenant tous les joueurs qui seront présents au tour suivant (ayant gagné leur combat)

                for (int i = 0; i < 1; i++) // On fait jouer tous les matchs (automatiques si c'est des ordinateurs, controlé si c'est le joueur)
                {
                    Combat match = new Combat(finale.round[i, 1], finale.round[i, 0]); // Combat
                    Equipe equipe = match.JoueurGagnant; // On récupère le joueur gagnant du match et on l'ajoute à la liste des gagnants
                    TableauSuivant.Add(equipe);
                }
                
                Console.Clear();
                Console.WriteLine("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t");
                Console.WriteLine("\t .                                                                                             .   ");
                Console.WriteLine("\t /       ___       _   __   ___  ` , __     ___.  ,   .   ___  ,   . .___         ___    ____ _/_  ");
                Console.WriteLine("\t |     .'   `      |   /   /   ` | |'  `. .'   `  |   | .'   ` |   | /   \\      .'   `  (      |   ");
                Console.WriteLine("\t |     |----'      `  /   |    | | |    | |    |  |   | |----' |   | |   '      |----'  `--.   |   ");
                Console.WriteLine("\t /---/ `.___,       \\/    `.__/| / /    |  `---|. `._/| `.___, `._/| /          `.___, \\___.'  \\__/");
                Console.WriteLine("\t                                               |/                                                  ");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("\t\t\t\t##################################################");
                Console.WriteLine("\t\t\t\t##\t\t\t" + TableauSuivant[0].NomEquipe+ "\t\t\t##");
                Console.WriteLine("\t\t\t\t##################################################");
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("\t\t\t\t Son équipe :");
                Console.WriteLine("");
                Console.WriteLine("┌─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐");
                Console.WriteLine("│             ┌─────────────────────────────────────────────┐                                                         │");
                Console.WriteLine("│             │   Pokemons : Pv/Puissance/Type/Faiblesse    │                                                         │");
                Console.WriteLine("│             │                                             │                                                         │");
                Console.WriteLine("│             │                                             │                                                         │");
                Console.WriteLine("│             │                                             │                                                         │");
                Console.WriteLine("│ Vainqueur : │   " + TableauSuivant[0].Pokémon1.Nom + " : " + TableauSuivant[0].Pokémon1.PvMax + "/" + TableauSuivant[0].Pokémon1.Puissance + "/" + TableauSuivant[0].Pokémon1.Type + "/" + TableauSuivant[0].Pokémon1.Faiblesse + "\t\t    │                                                         │");
                Console.WriteLine("│             │                                             │                                                         │");
                Console.WriteLine("│             │   " + TableauSuivant[0].Pokémon2.Nom + " : " + TableauSuivant[0].Pokémon2.PvMax + "/" + TableauSuivant[0].Pokémon2.Puissance + "/" + TableauSuivant[0].Pokémon2.Type + "/" + TableauSuivant[0].Pokémon2.Faiblesse + "\t\t    │                                                         │");
                Console.WriteLine("│             │                                             │                                                         │");
                Console.WriteLine("│             │   " + TableauSuivant[0].Pokémon3.Nom + " : " + TableauSuivant[0].Pokémon3.PvMax + "/" + TableauSuivant[0].Pokémon3.Puissance + "/" + TableauSuivant[0].Pokémon3.Type + "/" + TableauSuivant[0].Pokémon3.Faiblesse + "\t\t    │                                                         │");
                Console.WriteLine("│             │                                             │                                                         │");
                Console.WriteLine("│             │                                             │                                                         │");
                Console.WriteLine("│             └─────────────────────────────────────────────┘                                                         │");
                Console.WriteLine("├─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤");
                Console.ReadKey();
                Console.WriteLine("\t\t\t\t____ ____  _ ____ _  _ ____ ____    __.");
                Console.WriteLine("\t\t\t\t|__/ |___  | |  | |  | |___ |__/     _]");
                Console.WriteLine("\t\t\t\t|  \\ |___ _| |__| |__| |___ |  \\     . ");
                Console.WriteLine("");
                Console.WriteLine("\t\t\t\t(Pour quitter tappez \"non\")");

                rejoue = Console.ReadLine();
                
            } while (!(rejoue=="non"));

        }
    }
}
