﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokemonProgAvancée
{
    class Combat
    {
        public Random alea = new Random();

        public List<Pokemons> enVie1 { get; set; } //Liste des pokémons du joueur 1 encore en vie
        public List<Pokemons> enVie2 { get; set; } // Liste des pokémons du joueur 2 encore en vie
        public Pokemons PokeActif1 { get; set; } // Pokémon du joueur 1 en combat
        public Pokemons PokeActif2 { get; set; } // Pokémon du joueur 2 en combat
        public Equipe JoueurGagnant { get; private set; } // Joueur gagnant du combat
        

        public Combat(Equipe joueur1, Equipe joueur2)
        {
            // Remplit les liste des pokémons en vie de chaque joueur

            enVie1 = new List<Pokemons> { };
            enVie2 = new List<Pokemons> { };
            enVie1.Add(joueur1.Pokémon1);
            enVie1.Add(joueur1.Pokémon2);
            enVie1.Add(joueur1.Pokémon3);
            enVie2.Add(joueur2.Pokémon1);
            enVie2.Add(joueur2.Pokémon2);
            enVie2.Add(joueur2.Pokémon3);

            if(joueur1.player == true || joueur2.player == true) //Procède à l'affichage si un des deux dresseur est un vrai joueur (pas un ordinateur)
            {
                if (joueur1.player == true)
                {
                    AffichageDebutCombat(joueur1, joueur2, enVie1);
                }
                if (joueur2.player == true)
                {
                    AffichageDebutCombat(joueur2, joueur1, enVie2);
                }
            }
            else
            {
                PokeActif1 = ChoixPokemonActif(joueur1, enVie1);
            }

            int rdm = alea.Next(0, 3);
            PokeActif2 = enVie2[rdm]; // Assigne aléatoirement un pokémon actif à l'ordinateur

            do
            {
                Tour(joueur1, joueur2, PokeActif1, PokeActif2);
            } while (!(enVie1.Count==0|| enVie2.Count == 0)); // Tant que tous les pokémons d'un même dresseur ne sont pas morts, le combat continue
            
            if (enVie1.Count==0)
            {
                Console.WriteLine("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t");
                Console.WriteLine(joueur1.NomEquipe + " VS "+joueur2.NomEquipe+" : LE VAINQUEUR EST : " + joueur2.NomEquipe); // Affiche le nom du vainqueur
                JoueurGagnant = joueur2;
            }
            if(enVie2.Count==0)
            {
                Console.WriteLine("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t");
                Console.WriteLine(joueur1.NomEquipe + " VS " + joueur2.NomEquipe + " : LE VAINQUEUR EST : " + joueur1.NomEquipe); // Affiche le nom du vainqueur
                JoueurGagnant = joueur1;
            }
            //on remet les Pv au max
            JoueurGagnant.Pokémon1.Reset();
            JoueurGagnant.Pokémon2.Reset();
            JoueurGagnant.Pokémon3.Reset();
            //on remet le nombre de morts à zero
            JoueurGagnant.Pokémon1.NbMort=0;
            JoueurGagnant.Pokémon2.NbMort = 0;
            JoueurGagnant.Pokémon3.NbMort = 0;
        }

        public void Tour (Equipe joueur1, Equipe joueur2,Pokemons poke1, Pokemons poke2)
        {
            Pokemons p1 = poke1;
            Pokemons p2 = poke2;
            Random alea = new Random();
            int commence =  alea.Next(1, 3);
            if (commence == 1) // Le pokémon du joueur 1 commence
            {
                /*********************************Les 4 if avec les count permettentde faire des attaques que lorsqu'il reste des pokémons dans les deux équipes**************************/
                //joueur1 attaque

                if (enVie1.Count != 0 && enVie2.Count != 0)
                {
                    
                    //Le pokémon du joueur 1 attaque le pokémon du joueur 2 AVEC FAIBLESSE
                    if (p2.Faiblesse == p1.Type)
                    {
                        p2.Pv -= (p1.Puissance * 2);
                        if (p2.Pv < 0) { p2.Pv = 0; }
                        AffichageCombat(joueur1, joueur2, p1, p2, p1.Nom + " a attaqué " + p2.Nom + " il lui reste donc " + p2.Pv + " Pv");
                    }
                    //Le pokémon du joueur 1 attaque le pokémon du joueur 2 SANS FAIBLESSE
                    else
                    {
                        p2.Pv -= p1.Puissance;
                        if (p2.Pv < 0) { p2.Pv = 0; }
                        AffichageCombat(joueur1, joueur2, p1, p2,  p1.Nom + " a attaqué " + p2.Nom + " il lui reste donc " + p2.Pv + " Pv");
                    }
                    //On vérifie si le pokémon 2 est mort et si oui on l'enlève de la liste et on choisit le nouveau pokémon actif
                    if (verifMort(p2) == true)
                    {
                        //le pokemon du joueur 1 a tué le pokémon 2 donc sont nb de morts augmente et le nb de morts du pokemon 2 revient à zero
                        p1.NbMort++;
                        p2.NbMort = 0;
                        enVie2.Remove(p2);
                        PokeActif2 = ChoixPokemonActif(joueur2, enVie2);
                        p2 = PokeActif2;
                        AffichageCombat(joueur1, joueur2, p1, p2,"Il est K.O. Il a choisi son nouveau pokémon : "+PokeActif2.Nom);

                        if (p1.NbMort == 2) //evolution
                        {
                            p1 = p1.Evolution(p1);
                            AffichageCombat(joueur1, joueur2, p1, p2, p1.Nom + " a évolué !");
                        }
                    }
                    p2 = PokeActif2;
                }
                //joueur 2 attaque
                if (enVie1.Count != 0 && enVie2.Count != 0)
                {
                    //Le pokémon du joueur 2 attaque le pokémon du joueur 1 AVEC FAIBLESSE
                    if (p1.Faiblesse == p2.Type)
                    {
                        p1.Pv -= (p2.Puissance * 2);
                        if (p1.Pv < 0) { p1.Pv = 0; }
                        AffichageCombat(joueur1, joueur2, p1, p2, p2.Nom + " a attaqué " + p1.Nom + " il lui reste donc " + p1.Pv + " Pv");
                    }
                    //Le pokémon du joueur 2 attaque le pokémon du joueur 1 SANS FAIBLESSE
                    else
                    {
                        p1.Pv -= p2.Puissance;
                        if (p1.Pv < 0) { p1.Pv = 0; }
                        AffichageCombat(joueur1, joueur2, p1, p2, p2.Nom + " a attaqué " + p1.Nom + " il lui reste donc " + p1.Pv + " Pv");
                    }
                    //On vérifie si le pokémon 1 est mort et si oui on l'enlève de la liste et on choisit le nouveau pokémon actif
                    if (verifMort(p1) == true)
                    {
                        //le pokemon du joueur 2 a tué le pokémon 1 donc sont nb de morts augmente et le nb de morts du pokemon 1 revient à zero
                        p2.NbMort++;
                        p1.NbMort = 0;
                        enVie1.Remove(p1);
                        AffichageCombat(joueur1, joueur2, p1, p2, "Ton pokémon est K.O.");
                        PokeActif1 = ChoixPokemonActif(joueur1, enVie1);
                        p1 = PokeActif1;
                        if (p2.NbMort == 2) //evolution
                        {
                            p2 = p2.Evolution(p2);
                            AffichageCombat(joueur1, joueur2, p1, p2, p2.Nom + " a évolué !");
                        }
                    }
                    p1 = PokeActif1;
                }
            }
            //joueur 2 commence 
            if (commence == 2)
            {
                //joueur 2
                if (enVie1.Count != 0 && enVie2.Count != 0)
                {
                    //Le pokémon du joueur 2 attaque le pokémon du joueur 1 AVEC FAIBLESSE
                    if (p1.Faiblesse == p2.Type)
                    {
                        p1.Pv -= (p2.Puissance * 2);
                        if (p1.Pv < 0) { p1.Pv = 0; }
                        AffichageCombat(joueur1, joueur2, p1, p2, p2.Nom + " a attaqué " + p1.Nom + " il lui reste donc " + p1.Pv + " Pv");
                    }
                    //Le pokémon du joueur 2 attaque le pokémon du joueur 1 SANS FAIBLESSE
                    else
                    {
                        p1.Pv -= p2.Puissance;
                        if (p1.Pv < 0) { p1.Pv = 0; }
                        AffichageCombat(joueur1, joueur2, p1, p2, p2.Nom + " a attaqué " + p1.Nom + " il lui reste donc " + p1.Pv + " Pv");
                    }
                    //On vérifie si le pokémon 1 est mort et si oui on l'enlève de la liste et on choisit le nouveau pokémon actif
                    if (verifMort(p1) == true)
                    {
                        //le pokemon du joueur 2 a tué le pokémon 1 donc sont nb de morts augmente et le nb de morts du pokemon 1 revient à zero
                        p2.NbMort++;
                        p1.NbMort = 0;
                        enVie1.Remove(p1);
                        AffichageCombat(joueur1, joueur2, p1, p2, "Ton pokémon est K.O.");
                        PokeActif1 = ChoixPokemonActif(joueur1, enVie1);
                        p1 = PokeActif1;
                        if (p2.NbMort == 2) //evolution
                        {
                            p2 = p2.Evolution(p2);
                            AffichageCombat(joueur1, joueur2, p1, p2, p2.Nom + " a évolué !");
                        }
                    }
                    p1 = PokeActif1;
                }
                //joueur 1
                if (enVie1.Count != 0 && enVie2.Count != 0)
                {
                    //Le pokémon du joueur 1 attaque le pokémon du joueur 2 AVEC FAIBLESSE
                    if (p2.Faiblesse == p1.Type)
                    {
                        p2.Pv -= (p1.Puissance * 2);
                        if (p2.Pv < 0) { p2.Pv = 0; }
                        AffichageCombat(joueur1, joueur2, p1, p2, p1.Nom + " a attaqué " + p2.Nom + " il lui reste donc " + p2.Pv + " Pv");
                    }
                    //Le pokémon du joueur 1 attaque le pokémon du joueur 2 SANS FAIBLESSE
                    else
                    {
                        p2.Pv -= p1.Puissance;
                        if (p2.Pv <0) { p2.Pv = 0; }
                        AffichageCombat(joueur1, joueur2, p1, p2, p1.Nom + " a attaqué " + p2.Nom + " il lui reste donc " + p2.Pv + " Pv");
                    }
                    //On vérifie si le pokémon 2 est mort et si oui on l'enlève de la liste et on choisit le nouveau pokémon actif
                    if (verifMort(p2) == true && joueur2.player == false)
                    {
                        //le pokemon du joueur 1 a tué le pokémon 2 donc sont nb de morts augmente et le nb de morts du pokemon 2 revient à zero
                        p1.NbMort++;
                        p2.NbMort = 0;
                        enVie2.Remove(p2);
                        PokeActif2 = ChoixPokemonActif(joueur2, enVie2);
                        p2 = PokeActif2;
                        AffichageCombat(joueur1, joueur2, p1, p2, "Il est K.O. Il a choisi son nouveau pokémon : " + PokeActif2.Nom);
                        if (p1.NbMort == 2) //evolution
                        {
                            p1 = p1.Evolution(p1);
                            AffichageCombat(joueur1, joueur2, p1, p2, p1.Nom + " a évolué !");
                        }
                    }
                    p2 = PokeActif2;
                }
            }
        }

        public bool verifMort(Pokemons p)
        {
            if (p.Pv <=0)
            {
                //on remet son compteur de mort à 0
                p.NbMort = 0;
                return true;
            }
            return false;
        }
        public Pokemons ChoixPokemonActif(Equipe e, List<Pokemons> enVie)
        {
            if (enVie.Count==0) //si il n'y a plus de pokémons
            {
                Pokemons pokefauxfindejeu = new Pokemons("      ", -10, -10, "    ", "    ");
                //finDeCombat();
                return pokefauxfindejeu;
            }
            else //sinon choix pokémon
            {
                if (e.player == true)
                {
                    int i = 1;
                    foreach (Pokemons p in enVie)
                    {
                        Console.WriteLine("\t\tPokémon " + i + " : " + p.Nom);
                        i++;
                    }
                    int num = 0;
                    int number;
                    do
                    {
                        Console.WriteLine("\t\tQuel pokémon veux-tu faire combattre ? (numéro)");
                        string reponse = Console.ReadLine();
                        //essaye de convertir en int la reponse
                        bool success = Int32.TryParse(reponse, out number);
                        if (success == true)//si la reponse a été converti sans erreur alors c'est un nombre et on peut le convertir
                        {
                            num = Convert.ToInt32(reponse);
                        }
                        else num = -1; //sinon cela signifie que ce qui a été rentré est une chaine de caractère : non
                    }
                    while (num !=1 && num !=2 && num !=3);
                    if (num == 1)
                    {
                        return enVie[0];
                    }
                    if (num == 2)
                    {
                        return enVie[1];
                    }
                    else
                    {
                        return enVie[2];
                    }
                }
                else //ordi intelligent
                {
                    if (enVie[0]==enVie1[0]) //on prend en compte la liste envie2
                    {
                        foreach(Pokemons p2 in enVie2)
                        {
                            foreach(Pokemons p in enVie)
                            {
                                if (p.Type == p2.Faiblesse)
                                {
                                    return p;
                                }
                                else
                                {
                                    //rien
                                }
                            }
                        }
                        foreach (Pokemons p2 in enVie2)
                        {
                            foreach (Pokemons p in enVie)
                            {
                                if (p.Faiblesse != p2.Type)
                                {
                                    return p;
                                }
                                else
                                {
                                    //rien
                                }
                            }
                        }
                        return enVie[0];
                    }
                    else //envie[0]=envie2[0] donc on prend en compte la liste envie1
                    {
                        foreach (Pokemons p1 in enVie1)
                        {
                            foreach (Pokemons p in enVie)
                            {
                                if (p.Type == p1.Faiblesse)
                                {
                                    return p;
                                }
                                else
                                {
                                    //rien
                                }
                            }
                        }
                        foreach (Pokemons p1 in enVie2)
                        {
                            foreach (Pokemons p in enVie)
                            {
                                if (p.Faiblesse != p1.Type)
                                {
                                    return p;
                                }
                                else
                                {
                                    //rien
                                }
                            }
                        }
                        return enVie[0];
                    }
                }
            }
            
        }

        public void AffichageCombat(Equipe j1, Equipe j2, Pokemons p1, Pokemons p2, string message)
        {
            if(j1.player==true ||j2.player==true) //si un des joueurs est un humain alors on affiche le combat
            {
                //permet d'afficher le nombre de pokémons restants en fct du nb de pokémons KO
                string poke1rest = "";
                if (enVie1.Count == 3)
                {
                    poke1rest = "■ ■ ■";
                }
                if (enVie1.Count == 2)
                {
                    poke1rest = "o ■ ■";
                }
                if (enVie1.Count == 1)
                {
                    poke1rest = "o o ■";
                }
                if (enVie1.Count == 0)
                {
                    poke1rest = "o o o";
                }
                string poke2rest = "";
                if (enVie2.Count == 3)
                {
                    poke2rest = "■ ■ ■";
                }
                if (enVie2.Count == 2)
                {
                    poke2rest = "o ■ ■";
                }
                if (enVie2.Count == 1)
                {
                    poke2rest = "o o ■";
                }
                if (enVie2.Count == 0)
                {
                    poke2rest = "o o o";
                }



                Console.Clear();

                Console.BackgroundColor = ConsoleColor.Gray;
                Console.ForegroundColor = ConsoleColor.Black;



                Console.WriteLine("┌─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐");
                Console.WriteLine("│             ┌───────────────────────────────┐              ┌─────────────────────────────────────────────┐          │");
                Console.WriteLine("│             │ \t" + j1.NomEquipe + "\t\t      │              │                                             │          │");
                Console.WriteLine("│             │                               │              │   Pokemons : Pv/Puissance/Type/Faiblesse    │          │");
                Console.WriteLine("│             │   " + p1.Nom + "\t\t      │              │                                             │          │");
                Console.WriteLine("│    ┌────────┤                               │              │                                             │          │");
                Console.WriteLine("│    │        │   PV : " + p1.Pv + "\t              │              │                                             │          │");
                Console.WriteLine("│    │  " + poke1rest + " │   Puissance : " + p1.Puissance + "             │              │   " + j1.Pokémon1.Nom + " : " + j1.Pokémon1.PvMax + "/" + j1.Pokémon1.Puissance + "/" + j1.Pokémon1.Type + "/" + j1.Pokémon1.Faiblesse + "\t\t       │          │");
                Console.WriteLine("│    │        │   Type : " + p1.Type + "\t\t      │              │                                             │          │");
                Console.WriteLine("│    └────────┤                               │              │   " + j1.Pokémon2.Nom + " : " + j1.Pokémon2.PvMax + "/" + j1.Pokémon2.Puissance + "/" + j1.Pokémon2.Type + "/" + j1.Pokémon2.Faiblesse + "\t\t       │          │");
                Console.WriteLine("│             │                               │              │                                             │          │");
                Console.WriteLine("│             │                               │              │   " + j1.Pokémon3.Nom + " : " + j1.Pokémon3.PvMax + "/" + j1.Pokémon3.Puissance + "/" + j1.Pokémon3.Type + "/" + j1.Pokémon3.Faiblesse + "\t\t       │          │");
                Console.WriteLine("│             │                               │              │                                             │          │");
                Console.WriteLine("│             └───────────────────────────────┘              └─────────────────────────────────────────────┘          │");
                Console.WriteLine("├─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤");
                Console.WriteLine("│                                                                                                                     │");
                Console.WriteLine("│     ┌─────────────────────────────────────────────┐                  ┌───────────────────────────────┐              │");
                Console.WriteLine("│     │                                             │                  │       \t" + j2.NomEquipe + "\t\t       │              │");
                Console.WriteLine("│     │   Pokemons : Pv/Puissance/Type/Faiblesse    │                  │                               │              │");
                Console.WriteLine("│     │                                             │                  │   " + p2.Nom + "\t\t       │              │");
                Console.WriteLine("│     │                                             │                  │                               ├────────┐     │");
                Console.WriteLine("│     │   " + j2.Pokémon1.Nom + " : " + j2.Pokémon1.PvMax + "/" + j2.Pokémon1.Puissance + "/" + j2.Pokémon1.Type + "/" + j2.Pokémon1.Faiblesse + "\t\t    │                  │   PV : " + p2.Pv + "\t               │        │     │");
                Console.WriteLine("│     │                                             │                  │   Puissance : " + p2.Puissance + "             │ " + poke2rest + "  │     │");
                Console.WriteLine("│     │   " + j2.Pokémon2.Nom + " : " + j2.Pokémon2.PvMax + "/" + j2.Pokémon2.Puissance + "/" + j2.Pokémon2.Type + "/" + j2.Pokémon2.Faiblesse + "\t\t    │                  │   Type : " + p2.Type + "\t\t\t   │        │     │");
                Console.WriteLine("│     │                                             │                  │                               ├────────┘     │");
                Console.WriteLine("│     │   " + j2.Pokémon3.Nom + " : " + j2.Pokémon3.PvMax + "/" + j2.Pokémon3.Puissance + "/" + j2.Pokémon3.Type + "/" + j2.Pokémon3.Faiblesse + "\t\t    │                  │                               │              │");
                Console.WriteLine("│     │                                             │                  │                               │              │");
                Console.WriteLine("│     │                                             │                  │                               │              │");
                Console.WriteLine("│     └─────────────────────────────────────────────┘                  └───────────────────────────────┘              │");
                Console.WriteLine("├─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤");
                Console.WriteLine("│                                                                                                                     │");
                Console.WriteLine("│                                                                                                                     │");
                Console.WriteLine("│                                                                                                                     │");
                Console.WriteLine("│                                                                                                                     │");
                Console.WriteLine("│            " + message + " \t\t\t\t\t\t      ");
                Console.ReadKey();
            }
            //sinon on affiche pas le combat parce que c'est des ordi !
        }

        public void AffichageDebutCombat(Equipe j1, Equipe j2, List<Pokemons> enVie)
        {
            if (j1.player == true || j2.player == true) //si un des joueurs est un humain alors on affiche le combat
            {

                Console.Clear();

                Console.BackgroundColor = ConsoleColor.Gray;
                Console.ForegroundColor = ConsoleColor.Black;
                Console.WriteLine("┌─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐");
                Console.WriteLine("│             ┌─────────────────────────────────────────────┐                                                         │");
                Console.WriteLine("│             │   Pokemons : Pv/Puissance/Type/Faiblesse    │                                                         │");
                Console.WriteLine("│             │                                             │                                                         │");
                Console.WriteLine("│             │                                             │                                                         │");
                Console.WriteLine("│             │                                             │                                                         │");
                Console.WriteLine("│   Moi :     │   " + j1.Pokémon1.Nom + " : " + j1.Pokémon1.PvMax + "/" + j1.Pokémon1.Puissance + "/" + j1.Pokémon1.Type + "/" + j1.Pokémon1.Faiblesse + "\t\t    │                                                         │");
                Console.WriteLine("│             │                                             │                                                         │");
                Console.WriteLine("│             │   " + j1.Pokémon2.Nom + " : " + j1.Pokémon2.PvMax + "/" + j1.Pokémon2.Puissance + "/" + j1.Pokémon2.Type + "/" + j1.Pokémon2.Faiblesse + "\t\t    │                                                         │");
                Console.WriteLine("│             │                                             │                                                         │");
                Console.WriteLine("│             │   " + j1.Pokémon3.Nom + " : " + j1.Pokémon3.PvMax + "/" + j1.Pokémon3.Puissance + "/" + j1.Pokémon3.Type + "/" + j1.Pokémon3.Faiblesse + "\t\t    │                                                         │");
                Console.WriteLine("│             │                                             │                                                         │");
                Console.WriteLine("│             │                                             │                                                         │");
                Console.WriteLine("│             └─────────────────────────────────────────────┘                                                         │");
                Console.WriteLine("├─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤");
                Console.WriteLine("│                                                                                                                     │");
                Console.WriteLine("│                                                            ┌─────────────────────────────────────────────┐          │");
                Console.WriteLine("│                                                            │   Pokemons : Pv/Puissance/Type/Faiblesse    │          │");
                Console.WriteLine("│                                                            │                                             │          │");
                Console.WriteLine("│                                                            │                                             │          │");
                Console.WriteLine("│                                                            │                                             │          │");
                Console.WriteLine("│                                                            │   " + j2.Pokémon1.Nom + " : " + j2.Pokémon1.PvMax + "/" + j2.Pokémon1.Puissance + "/" + j2.Pokémon1.Type + "/" + j2.Pokémon1.Faiblesse + "\t\t       │          │");
                Console.WriteLine("│                                       Mon adversaire :     │                                             │          │");
                Console.WriteLine("│                                                            │   " + j2.Pokémon2.Nom + " : " + j2.Pokémon2.PvMax + "/" + j2.Pokémon2.Puissance + "/" + j2.Pokémon2.Type + "/" + j2.Pokémon2.Faiblesse + "\t\t       │          │");
                Console.WriteLine("│                                                            │                                             │          │");
                Console.WriteLine("│                                                            │   " + j2.Pokémon3.Nom + " : " + j2.Pokémon3.PvMax + "/" + j2.Pokémon3.Puissance + "/" + j2.Pokémon3.Type + "/" + j2.Pokémon3.Faiblesse + "\t\t       │          │");
                Console.WriteLine("│                                                            │                                             │          │");
                Console.WriteLine("│                                                            │                                             │          │");
                Console.WriteLine("│                                                            └─────────────────────────────────────────────┘          │");
                Console.WriteLine("├─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┤");
                Console.WriteLine("│                                                                                                                     │");
                Console.WriteLine("│            Choisissez un pokémon !                                                                                  │");
                Console.WriteLine("│                                                                                                                     │");
                Console.WriteLine("│            Pokémon 1 : " + j1.Pokémon1.Nom + "\t\t\t\t                                                      │");
                Console.WriteLine("│            Pokémon 2 : " + j1.Pokémon2.Nom + "\t\t\t\t                                                      │");
                Console.WriteLine("│            Pokémon 3 : " + j1.Pokémon3.Nom + "\t\t\t\t                                                      │");
                Console.WriteLine("                              \t\t\t                                                                       ");
                int choix = 0;
                int number;
                do
                {
                    Console.WriteLine("Entrez le numéro associé :\t\t\t\t\t\t\t\t\t\t\t\t       ");
                    string reponse = Console.ReadLine();
                    //essaye de convertir en int la reponse
                    bool success = Int32.TryParse(reponse, out number);
                    if (success == true)//si la reponse a été converti sans erreur alors c'est un nombre et on peut le convertir
                    {
                        choix = Convert.ToInt32(reponse);
                    }
                    else choix = 0; //sinon cela signifie que ce qui a été rentré est une chaine de caractère : non
                } while (!(choix == 1 || choix == 2 || choix == 3));
                PokeActif1 = enVie[choix-1];
            }
            //sinon on affiche pas le combat parce que c'est des ordi !
        }
        
    }
}
