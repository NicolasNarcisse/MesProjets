﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokemonProgAvancée
{
    class Tableaux
    {
        public Random alea = new Random();

        public Equipe[,] round; //Création d'un tableau contenant les différents matchs

        public Tableaux(List<Equipe> toutesLesEquipes)
        {
            int a = 0;
            if (toutesLesEquipes.Count == 16) //Si la liste des équipes envoyées contient 16 équipes, cela signifie qu'il s'agit d'un tableau de huitième de finale.
            {
                round = new Equipe[8, 2]; // Instancie un nouveau tableau d'équipes à la taille souhaitée
                for (int i = 0; i < 8; i++) // Rentre chacune des équipes dans le tableau en gardant l'ordre des matchs
                {
                    round[i, 0] = toutesLesEquipes[a];
                    a++;
                    round[i, 1] = toutesLesEquipes[a];
                    a++;
                }
            }
            if (toutesLesEquipes.Count == 8) //Si la liste des équipes envoyées contient 8 équipes, cela signifie qu'il s'agit d'un tableau de quart de finale.
            {
                round = new Equipe[4, 2]; // Instancie un nouveau tableau d'équipes à la taille souhaitée
                for (int i = 0; i < 4; i++) // Rentre chacune des équipes dans le tableau en gardant l'ordre des matchs
                {
                    round[i, 0] = toutesLesEquipes[a];
                    a++;
                    round[i, 1] = toutesLesEquipes[a];
                    a++;
                }
            }
            if (toutesLesEquipes.Count == 4) //Si la liste des équipes envoyées contient 4 équipes, cela signifie qu'il s'agit d'un tableau de demi de finale.
            {
                round = new Equipe[2, 2]; // Instancie un nouveau tableau d'équipes à la taille souhaitée
                for (int i = 0; i < 2; i++) // Rentre chacune des équipes dans le tableau en gardant l'ordre des matchs
                {
                    round[i, 0] = toutesLesEquipes[a];
                    a++;
                    round[i, 1] = toutesLesEquipes[a];
                    a++;
                }
            }
            if (toutesLesEquipes.Count == 2) //Si la liste des équipes envoyées contient 2 équipes, cela signifie qu'il s'agit d'un tableau de finale.
            {
                round = new Equipe[1, 2]; // Instancie un nouveau tableau d'équipes à la taille souhaitée
                for (int i = 0; i < 1; i++) // Rentre chacune des équipes dans le tableau en gardant l'ordre des matchs
                {
                    round[i, 0] = toutesLesEquipes[a];
                    a++;
                    round[i, 1] = toutesLesEquipes[a];
                    a++;
                }
            }
        }

        public override string ToString() // Affichage du tableau en cours
        {
            if (round.Length == 16)
            {
                Console.WriteLine("Tableau des huitièmes de finale");
                for(int i = 0; i<8 ; i++)
                {
                    Console.WriteLine("Match n°" + (i+1) + " : " + round[i, 0].NomEquipe + " VS " + round[i, 1].NomEquipe); // Affichage de chaque match
                }
            }
            if (round.Length == 8)
            {
                Console.WriteLine("Tableau des quarts de finale");
                for (int i = 0; i < 4; i++)
                {
                    Console.WriteLine("Match n°" + (i + 1) + " : " + round[i, 0].NomEquipe + " VS " + round[i, 1].NomEquipe);// Affichage de chaque match
                }
            }
            if (round.Length == 4)
            {
                Console.WriteLine("Tableau des demies de finale");
                for (int i = 0; i < 2; i++)
                {
                    Console.WriteLine("Match n°" + (i + 1) + " : " + round[i, 0].NomEquipe + " VS " + round[i, 1].NomEquipe);// Affichage de chaque match
                }
            }
            if (round.Length == 2)
            {
                Console.WriteLine("Tableau de la finale");
                Console.WriteLine("Match final :" + round[0, 0].NomEquipe + " VS " + round[0, 1].NomEquipe);// Affichage du match
            }
            return "";
        }
        
    }
}
