﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokemonProgAvancée
{
    class Equipe
    {
        public string NomEquipe { get; set; }
        public Pokemons Pokémon1 { get; set; }
        public Pokemons Pokémon2 { get; set; }
        public Pokemons Pokémon3 { get; set; }
        public bool player { get; set; } // Permet de renseigner si c'est bien un joueur (true) ou un ordinateur (false)
        
        public Equipe (string nom,Pokemons p1, Pokemons p2, Pokemons p3, bool play)
        {
            NomEquipe = nom;
            Pokémon1 = p1;
            Pokémon2 = p2;
            Pokémon3 = p3;
            player = play;
        }

        
    }
}
