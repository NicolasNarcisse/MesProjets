﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokemonProgAvancée
{
    class ListeEquipe
    {
        public Random alea = new Random(); // Fonction aléatoire

        public List<Equipe> listeEquipe = new List<Equipe> { };

        List<Pokemons> bddpokemon2 = new List<Pokemons> { }; 

        List<string> noms = new List<string> { "Red", "Leaf", "Ludwig", "Ludvina", "Kalem", "Serena", "Florent", "Scout", "Silver", "Trovato", "Giovani", "Lysande", "Maladif", "Pierre", "Lem" }; // Liste des noms de dresseurs pour les joueurs ordinateurs

        public ListeEquipe(string nomJoueur)
        {
            BddPokemon pokemonsdispo = new BddPokemon(); //Crée une nouvelle base de donnée de pokémons grâce au constructeur BddPokemon
            pokemonsdispo.creaBasePokemons();
            bddpokemon2 = pokemonsdispo.bddpokemon; // Récupère la liste des pokémons de la base de donnée
            for (int i = 0; i < 15; i++)
            {
                string nomequipe = noms[i]; // Donne un nom au joueur
                int nb1;
                int nb2;
                int nb3;
                do // Attribut 3 pokémons au joueur
                {
                    nb1 = alea.Next(0, 47 - i * 3);
                    nb2 = alea.Next(0, 47 - i * 3);
                    nb3 = alea.Next(0, 47 - i * 3);

                } while (nb1==nb2 || nb2==nb3 || nb1==nb3); // on s'assure de ne pas donner deux fois le même pokémon au joueur
                
                Pokemons p1 = bddpokemon2[nb1];
                Pokemons p2 = bddpokemon2[nb2];
                Pokemons p3 = bddpokemon2[nb3];
                Equipe equipe = new Equipe(nomequipe, p1, p2, p3,false); // Crée l'équipe avec tous les paramètres grâce au constructeur Equipe

                // Retire les 3 pokémons de la liste des pokémons
                bddpokemon2.Remove(p1);
                bddpokemon2.Remove(p2);
                bddpokemon2.Remove(p3);

                listeEquipe.Add(equipe); // Ajoute la nouvelle équipe à le liste des équipes
            }

            Equipe joueur = new Equipe(nomJoueur, bddpokemon2[0], bddpokemon2[1], bddpokemon2[2],true); // Rajoute l'éqipe du joueur
            listeEquipe.Add(joueur);

        }
        public override string ToString()
        {
            for (int i = 0; i < 16; i++)
            {
                Console.WriteLine("Nom du dresseur : "+listeEquipe[i].NomEquipe+ ", Pokémon 1 : "+listeEquipe[i].Pokémon1.Nom+ ", Pokémon 2 : " + listeEquipe[i].Pokémon2.Nom+ ", Pokémon 3 : " + listeEquipe[i].Pokémon3.Nom);
            }
            return "";
        }
    }
}
