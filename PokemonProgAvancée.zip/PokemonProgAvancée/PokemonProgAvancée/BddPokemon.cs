﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokemonProgAvancée
{
    class BddPokemon
    {
        public Random alea = new Random();

        public List<Pokemons> bddpokemon = new List<Pokemons> { };

        //Liste des types et des faiblesse associées :
        string[,] types = new string[,] { { "Feu", "Eau" }, { "Terre", "Air" }, { "Eau", "Elec" }, { "Air", "Herbe" }, { "Herbe", "Feu" }, { "Elec", "Terre" } };

        //Liste des noms de pokémons
        List<string> nomspokemons = new List<string> {"Bulbiza", "Herbiza", "Floriza", "Salamèk", "Reptinç", "Dragof", "Carapuce", "Racailo", "Tortank", "Chenipan", "Chrysaf", "Papimami", "Aspicot", "Coconf", "Dardard", "Roucool","Mewtwo", "Ronflex",
            "Rattata", "Cabutor", "Piafabec", "Grolema", "Tentaco", "Arbokar", "Pikachu", "Leviator", "Sabelet", "Magiecar", "Nidoran", "Scarabo", "Mr mime", "Kangour", "Rhinopé", "Smogoro", "Mélofée", "Osselé", "Groupix", "Feunard", "Rondoux", "Voltrob", "Nosfera", "Sorifik", "Mysther", "Ortide"
            ,"Rafléya", "Parasit", "Onixart", "Mimitos" };

        public void creaBasePokemons() //Créé une base de donnée créant aléatoirement les pokémons
        {
            for (int i = 0; i < 48; i++)
            {
                int pv = alea.Next(600, 800);
                int puissance = alea.Next(200, 301);
                int nb = alea.Next(0, 6);
                string type = types[nb, 0];
                string faiblesse = types[nb, 1];
                Pokemons P = new Pokemons(nomspokemons[i], pv, puissance, type, faiblesse);
                bddpokemon.Add(P);
            }
        }
    }
}
